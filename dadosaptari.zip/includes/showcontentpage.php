<div id="content" class="cf" style="width:75%">
<?php //include("includes/breadcrumb.php"); ?>
<article class="single-view post-77 page type-page status-publish hentry">
    <header class="entry-header cf"><h2 class="entry-title"><?php echo $pageName; ?></h2></header>
    <div class="entry-byline cf">
    </div>
    <div class="entry-content cf">
    	<?php
		$pagename = "index.php?id=". $pageId ."&";
		include("includes/pagination.php");
		echo Pagination($pageContents, "content");
		?>
    </div>
</article>
</div>